import { contextBridge, ipcRenderer } from 'electron';
import type {
  CopyOptions,
  CopyProgress,
  FileEntry,
  ScanOptions,
  ScanProgress,
} from '../shared/types';

type Unsub = () => void;

const api = {
  pickFolder: (defaultPath?: string): Promise<string | null> =>
    ipcRenderer.invoke('dialog:pickFolder', defaultPath),
  pickDestFolder: (defaultPath?: string): Promise<string | null> =>
    ipcRenderer.invoke('dialog:saveFolder', defaultPath),

  scan: {
    start(opts: ScanOptions, cbs: {
      onEntries?: (entries: FileEntry[]) => void;
      onProgress?: (p: ScanProgress) => void;
      onError?: (msg: string) => void;
      onDone?: (s: { scanned: number; bytes: number; errors: number; elapsedMs: number }) => void;
    }): { jobId: string; cancel: () => void; cleanup: Unsub } {
      const jobId = `s${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
      const onEntries = (_e: any, entries: FileEntry[]) => cbs.onEntries?.(entries);
      const onProgress = (_e: any, p: any) => cbs.onProgress?.({ ...p, done: false });
      const onError = (_e: any, msg: string) => cbs.onError?.(msg);
      const onDone = (_e: any, s: any) => {
        cbs.onProgress?.({ ...s, done: true, currentPath: '' });
        cbs.onDone?.(s);
        cleanup();
      };
      ipcRenderer.on(`scan:${jobId}:entries`, onEntries);
      ipcRenderer.on(`scan:${jobId}:progress`, onProgress);
      ipcRenderer.on(`scan:${jobId}:error`, onError);
      ipcRenderer.on(`scan:${jobId}:done`, onDone);
      ipcRenderer.invoke('scan:start', jobId, opts);
      const cleanup: Unsub = () => {
        ipcRenderer.removeListener(`scan:${jobId}:entries`, onEntries);
        ipcRenderer.removeListener(`scan:${jobId}:progress`, onProgress);
        ipcRenderer.removeListener(`scan:${jobId}:error`, onError);
        ipcRenderer.removeListener(`scan:${jobId}:done`, onDone);
      };
      return {
        jobId,
        cancel: () => ipcRenderer.invoke('scan:cancel', jobId),
        cleanup,
      };
    },
  },

  copy: {
    start(opts: CopyOptions, cbs: {
      onProgress?: (p: CopyProgress) => void;
      onDone?: (errors: { path: string; message: string }[]) => void;
    }): { jobId: string; cancel: () => void; cleanup: Unsub } {
      const jobId = `c${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
      const onProgress = (_e: any, p: any) => cbs.onProgress?.(p);
      const onDone = (_e: any, errs: any) => {
        cbs.onDone?.(errs);
        cleanup();
      };
      ipcRenderer.on(`copy:${jobId}:progress`, onProgress);
      ipcRenderer.on(`copy:${jobId}:done`, onDone);
      ipcRenderer.invoke('copy:start', jobId, opts);
      const cleanup: Unsub = () => {
        ipcRenderer.removeListener(`copy:${jobId}:progress`, onProgress);
        ipcRenderer.removeListener(`copy:${jobId}:done`, onDone);
      };
      return {
        jobId,
        cancel: () => ipcRenderer.invoke('copy:cancel', jobId),
        cleanup,
      };
    },
  },

  shell: {
    openInExplorer: (p: string) => ipcRenderer.invoke('shell:openInExplorer', p),
    openPath: (p: string) => ipcRenderer.invoke('shell:openPath', p),
  },

  clipboard: {
    writeText: (txt: string) => ipcRenderer.invoke('clipboard:writeText', txt),
    writePaths: (paths: string[]) => ipcRenderer.invoke('clipboard:writePaths', paths),
  },

  files: {
    trash: (paths: string[]) => ipcRenderer.invoke('files:trash', paths),
    permanentDelete: (paths: string[]) => ipcRenderer.invoke('files:permanentDelete', paths),
  },

  system: {
    listDrives: (): Promise<string[]> => ipcRenderer.invoke('system:listDrives'),
    appVersion: (): Promise<string> => ipcRenderer.invoke('system:appVersion'),
    homeDir: (): Promise<string> => ipcRenderer.invoke('system:homeDir'),
    onUpdateStatus(cb: (s: any) => void): Unsub {
      const h = (_e: any, s: any) => cb(s);
      ipcRenderer.on('updater:status', h);
      return () => ipcRenderer.removeListener('updater:status', h);
    },
  },
};

contextBridge.exposeInMainWorld('api', api);

export type SmartExplorerAPI = typeof api;

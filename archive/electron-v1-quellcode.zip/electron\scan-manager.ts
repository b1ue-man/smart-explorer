import { Worker } from 'node:worker_threads';
import { readdirSync, lstatSync } from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { EventEmitter } from 'node:events';
import type { FileEntry, ScanOptions } from '../shared/types';

const WORKER_PATH_PROD = path.join(__dirname, 'scan-worker.cjs');

export type ScanEvents = {
  entries: (entries: FileEntry[]) => void;
  progress: (p: { scanned: number; bytes: number; errors: number; currentPath?: string; elapsedMs: number }) => void;
  done: (s: { scanned: number; bytes: number; errors: number; elapsedMs: number }) => void;
  error: (msg: string) => void;
};

function normalize(p: string) {
  return p.replace(/\\/g, '/');
}

/**
 * Distribute work across N workers. Strategy:
 *   1. Enumerate immediate children of root on main thread.
 *   2. Files at root → emit directly.
 *   3. Subdirs at root → if count < 2*workers, expand one level to balance.
 *   4. Round-robin assign each subdir to a worker.
 */
export class ScanManager extends EventEmitter {
  private workers: Worker[] = [];
  private cancelled = false;
  private startTime = 0;
  private aggregate = { scanned: 0, bytes: 0, errors: 0 };
  private lastSampledPath = '';
  private workersDone = 0;
  private resolveDone: ((v: void) => void) | null = null;

  on<E extends keyof ScanEvents>(e: E, cb: ScanEvents[E]): this {
    return super.on(e, cb as any);
  }
  emit<E extends keyof ScanEvents>(e: E, ...args: Parameters<ScanEvents[E]>): boolean {
    return super.emit(e, ...(args as any));
  }

  cancel() {
    this.cancelled = true;
    for (const w of this.workers) w.terminate().catch(() => {});
    this.workers = [];
  }

  async start(opts: ScanOptions): Promise<void> {
    this.startTime = Date.now();
    this.aggregate = { scanned: 0, bytes: 0, errors: 0 };
    this.workersDone = 0;

    const rootRaw = opts.root;
    const root = path.resolve(rootRaw);

    // Emit the root entry itself
    try {
      const st = lstatSync(root);
      const rootEntry: FileEntry = {
        path: normalize(root),
        parent: normalize(path.dirname(root)),
        name: path.basename(root) || root,
        ext: '',
        size: 0,
        mtimeMs: st.mtimeMs,
        birthtimeMs: st.birthtimeMs || st.ctimeMs,
        isDir: true,
        isSymlink: st.isSymbolicLink(),
        hidden: false,
        system: false,
        depth: 0,
      };
      this.emit('entries', [rootEntry]);
    } catch (e: any) {
      this.emit('error', `Cannot stat root: ${e.message}`);
      this.emit('done', { ...this.aggregate, elapsedMs: 0 });
      return;
    }

    // Enumerate root's immediate children
    let topLevel: { name: string; isDir: boolean; isSymlink: boolean }[] = [];
    try {
      topLevel = readdirSync(root, { withFileTypes: true }).map((d) => ({
        name: d.name,
        isDir: d.isDirectory(),
        isSymlink: d.isSymbolicLink(),
      }));
    } catch (e: any) {
      this.emit('error', `Cannot read root: ${e.message}`);
      this.emit('done', { ...this.aggregate, elapsedMs: 0 });
      return;
    }

    // Emit top-level files synchronously (fast path)
    const topLevelFileEntries: FileEntry[] = [];
    const subdirs: string[] = [];
    for (const t of topLevel) {
      const full = path.join(root, t.name);
      try {
        const st = lstatSync(full);
        const entry: FileEntry = {
          path: normalize(full),
          parent: normalize(root),
          name: t.name,
          ext: t.isDir ? '' : path.extname(t.name).slice(1).toLowerCase(),
          size: Number(st.size),
          mtimeMs: st.mtimeMs,
          birthtimeMs: st.birthtimeMs || st.ctimeMs,
          isDir: t.isDir,
          isSymlink: t.isSymlink,
          hidden: t.name.startsWith('.'),
          system: false,
          depth: 1,
        };
        if (!opts.includeHidden && entry.hidden) continue;
        topLevelFileEntries.push(entry);
        this.aggregate.scanned++;
        if (!t.isDir) this.aggregate.bytes += Number(st.size);
        if (t.isDir && (!t.isSymlink || opts.followSymlinks)) {
          if (opts.maxDepth === undefined || 2 <= opts.maxDepth) {
            subdirs.push(full);
          }
        }
      } catch {
        this.aggregate.errors++;
      }
    }
    if (topLevelFileEntries.length) this.emit('entries', topLevelFileEntries);

    // If we have very few subdirs, descend one more level to improve balance
    const cpuCount = Math.max(2, Math.min(os.cpus().length, 16));
    let workItems: string[] = subdirs;
    if (workItems.length > 0 && workItems.length < cpuCount * 2) {
      const expanded: string[] = [];
      const overflowEntries: FileEntry[] = [];
      for (const d of workItems) {
        try {
          const children = readdirSync(d, { withFileTypes: true });
          for (const c of children) {
            const full = path.join(d, c.name);
            try {
              const st = lstatSync(full);
              const entry: FileEntry = {
                path: normalize(full),
                parent: normalize(d),
                name: c.name,
                ext: c.isDirectory() ? '' : path.extname(c.name).slice(1).toLowerCase(),
                size: Number(st.size),
                mtimeMs: st.mtimeMs,
                birthtimeMs: st.birthtimeMs || st.ctimeMs,
                isDir: c.isDirectory(),
                isSymlink: c.isSymbolicLink(),
                hidden: c.name.startsWith('.'),
                system: false,
                depth: 2,
              };
              if (!opts.includeHidden && entry.hidden) continue;
              overflowEntries.push(entry);
              this.aggregate.scanned++;
              if (!c.isDirectory()) this.aggregate.bytes += Number(st.size);
              if (c.isDirectory() && (!c.isSymbolicLink() || opts.followSymlinks)) {
                if (opts.maxDepth === undefined || 3 <= opts.maxDepth) {
                  expanded.push(full);
                }
              }
            } catch {
              this.aggregate.errors++;
            }
          }
        } catch {
          this.aggregate.errors++;
        }
      }
      if (overflowEntries.length) this.emit('entries', overflowEntries);
      // If expansion produced more leaves, use them; otherwise fall back to original list
      if (expanded.length >= workItems.length) workItems = expanded;
    }

    if (workItems.length === 0) {
      this.emit('progress', { ...this.aggregate, elapsedMs: Date.now() - this.startTime, currentPath: '' });
      this.emit('done', { ...this.aggregate, elapsedMs: Date.now() - this.startTime });
      return;
    }

    // Spawn workers and round-robin assign
    const workerCount = Math.min(cpuCount, workItems.length);
    const buckets: string[][] = Array.from({ length: workerCount }, () => []);
    for (let i = 0; i < workItems.length; i++) {
      buckets[i % workerCount].push(workItems[i]);
    }

    // Determine starting depth for workers — depth of items they receive
    const startDepth = workItems[0].split(path.sep).length - root.split(path.sep).length + 1;

    const donePromise = new Promise<void>((resolve) => {
      this.resolveDone = resolve;
    });

    for (let i = 0; i < workerCount; i++) {
      const w = new Worker(WORKER_PATH_PROD);
      this.workers.push(w);
      w.on('message', (msg: any) => this.handleWorkerMessage(w, msg));
      w.on('error', (err) => {
        this.aggregate.errors++;
        this.emit('error', `worker error: ${err.message}`);
      });
      w.on('exit', () => {
        // exit without 'done' message (e.g. terminate) — count as finished
        if (!this.cancelled) {
          this.workersDone++;
          if (this.workersDone >= workerCount) this.finish();
        }
      });
      w.postMessage({ type: 'scan', startDirs: buckets[i], startDepth, opts });
    }

    // Periodic progress sampler
    const progressTimer = setInterval(() => {
      if (this.cancelled) return clearInterval(progressTimer);
      this.emit('progress', {
        ...this.aggregate,
        elapsedMs: Date.now() - this.startTime,
        currentPath: this.lastSampledPath,
      });
    }, 200);

    await donePromise;
    clearInterval(progressTimer);
    this.emit('progress', {
      ...this.aggregate,
      elapsedMs: Date.now() - this.startTime,
      currentPath: this.lastSampledPath,
    });
    this.emit('done', { ...this.aggregate, elapsedMs: Date.now() - this.startTime });
  }

  private handleWorkerMessage(w: Worker, msg: any) {
    if (this.cancelled) return;
    switch (msg.type) {
      case 'entries':
        this.emit('entries', msg.entries);
        break;
      case 'progress':
        // Workers report cumulative-per-worker; we recompute aggregate by deltas in 'done'.
        // For now, just bump the counters monotonically — the final 'done' reconciles.
        break;
      case 'sample':
        this.lastSampledPath = msg.currentPath;
        break;
      case 'done':
        this.aggregate.scanned += msg.scanned;
        this.aggregate.bytes += msg.bytes;
        this.aggregate.errors += msg.errors;
        w.terminate().catch(() => {});
        this.workersDone++;
        if (this.workersDone >= this.workers.length) this.finish();
        break;
    }
  }

  private finish() {
    if (this.resolveDone) {
      const r = this.resolveDone;
      this.resolveDone = null;
      r();
    }
  }
}

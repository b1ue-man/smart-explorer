# Smart Explorer

Schneller, intelligenter Datei-Explorer für Windows mit tiefem Filtering und
struktur-erhaltendem Kopieren.

## Highlights

- **Paralleles Scannen** über alle CPU-Kerne mit Worker-Threads
- **Live-Streaming** der Resultate während des Scans (kein Warten auf Vollständigkeit)
- **Filter** nach Name (Substring/RegExp/Glob), Endung, Größenbereich, Änderungsdatum,
  Erstellungsdatum, Dateityp, versteckte/system Attribute, Tiefe
- **Kopieren / Verschieben** mit Erhalt der relativen Ordnerstruktur, **ohne leere Ordner**
- **Konfliktauflösung** beim Kopieren: umbenennen / überschreiben / überspringen
- **Papierkorb-Löschen** (Windows-nativ via Shell)
- **Auto-Update** über GitHub Releases (electron-updater)
- **Virtualisiertes Grid** rendert auch >1 Mio. Einträge flüssig
- **Statistik-Panel**: Top-Dateitypen, größte Dateien, älteste/neueste Datei
- **Tastenkürzel**: `Ctrl+A` alles auswählen, `Ctrl+C` Pfade in Zwischenablage,
  `Del` Papierkorb, `Esc` Auswahl löschen, `F5` neu scannen

## Build / Entwicklung

```bash
npm install
npm run dev      # Entwicklungsmodus mit Vite-HMR
npm run build    # Produktionsbundle bauen
npm run dist     # NSIS-Installer für Windows produzieren
```

Artefakt liegt nach `npm run dist` unter `release/Smart Explorer-Setup-<version>.exe`.

## Auto-Update

Auto-Update verwendet die `publish`-Konfiguration in `package.json`. Vor dem
ersten Release den `owner` auf den GitHub-Username setzen und den Build mit
`GH_TOKEN=<token> npm run dist` ausführen, um den Release direkt zu publishen.

`electron-updater` prüft beim Start und alle 6 Stunden auf Updates und installiert
neue Versionen beim nächsten App-Quit.

## Architektur

```
electron/
  main.ts              # Electron Main: Fenster, IPC, Shell-Bridges
  preload.ts           # Sicheres window.api-Bridge zum Renderer
  scan-manager.ts      # Verteilt Subtrees auf Worker-Pool
  copy-manager.ts      # Steuert den Copy-Worker
  updater.ts           # electron-updater-Konfiguration
  workers/
    scan-worker.ts     # Synchrones rekursives readdir + lstat, batcht Resultate
    copy-worker.ts     # copyFile mit Strukturpfad, Konflikten, Symlink-Handling
shared/
  types.ts             # Geteilte TypeScript-Types
  filter.ts            # Reine Filter-Engine (compileFilter)
  sort.ts              # Sortier-Vergleich + Format-Helfer
src/                    # React Renderer
  App.tsx              # Hauptlayout, State, Lifecycle
  components/
    Toolbar.tsx        # Pfadleiste + Aktions-Buttons
    Sidebar.tsx        # Quicklinks, Laufwerke, Verlauf
    FilterBar.tsx      # Filter-Steuerelemente
    FileGrid.tsx       # Virtualisiertes Daten-Grid
    StatusBar.tsx      # Scan-Progress, Update-Status
    SummaryPanel.tsx   # Statistik
    CopyDialog.tsx     # Kopier-Dialog mit Progress
```

## Performance

Auf einem Standard-NTFS-Laufwerk erreicht das Scannen je nach Verzeichnis:

- `node_modules` (~10k kleine Dateien): ~40-50k Einträge/s
- `C:\Program Files` (~500k Dateien, 90 GB): ~8-15k Einträge/s
  (Windows Defender ist hier der Engpass, nicht der Scanner)

Für noch höhere Geschwindigkeit (>500k/s wie WizTree) wäre direktes Lesen
der NTFS Master File Table nötig — Roadmap.

## Limitierungen

- NTFS-Attribute "hidden" / "system" werden auf Windows nur über Namens-Konvention
  (`.dot`-Präfix) erkannt; native Attribute brauchen ein Native-Modul.
- Kein Drag&Drop *aus* der App heraus (zur Explorer-Integration ein Native-Modul).
- Kein Code-Signing — Windows zeigt SmartScreen-Warnung. Für Release: EV-Cert.

## Lizenz

MIT

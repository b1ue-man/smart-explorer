import React, { useEffect, useState } from 'react';
import type { CopyProgress } from '../../shared/types';
import { formatBytes } from '../../shared/sort';

type Props = {
  mode: 'copy' | 'move';
  selectionCount: number;
  onClose: () => void;
  onConfirm: (dest: string, preserveStructure: boolean, conflict: 'skip' | 'overwrite' | 'rename') => void;
  progress?: CopyProgress;
};

export function CopyDialog({ mode, selectionCount, onClose, onConfirm, progress }: Props) {
  const [dest, setDest] = useState('');
  const [preserve, setPreserve] = useState(true);
  const [conflict, setConflict] = useState<'skip' | 'overwrite' | 'rename'>('rename');
  const running = !!progress && !progress.done;

  useEffect(() => {
    if (progress?.done) {
      // close after brief delay
      const t = setTimeout(onClose, 700);
      return () => clearTimeout(t);
    }
  }, [progress?.done, onClose]);

  const pickDest = async () => {
    const p = await window.api.pickDestFolder(dest || undefined);
    if (p) setDest(p);
  };

  const pct = progress
    ? progress.bytesTotal
      ? (progress.bytesDone / progress.bytesTotal) * 100
      : (progress.filesDone / Math.max(1, progress.filesTotal)) * 100
    : 0;

  return (
    <div className="modal-backdrop" onClick={running ? undefined : onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <div className="modal-title">
          {mode === 'copy' ? 'Kopieren' : 'Verschieben'} · {selectionCount} Einträge
        </div>

        <label className="row">
          Ziel:
          <input
            className="grow"
            value={dest}
            placeholder="Zielordner…"
            onChange={(e) => setDest(e.target.value)}
            disabled={running}
          />
          <button className="btn" onClick={pickDest} disabled={running}>
            Wählen…
          </button>
        </label>

        <label className="row">
          <input
            type="checkbox"
            checked={preserve}
            onChange={(e) => setPreserve(e.target.checked)}
            disabled={running}
          />{' '}
          Ordnerstruktur erhalten (leere Ordner werden weggelassen)
        </label>

        <div className="row">
          <span>Bei Konflikt:</span>
          {(['rename', 'overwrite', 'skip'] as const).map((c) => (
            <label key={c} className="pill">
              <input
                type="radio"
                name="conflict"
                value={c}
                checked={conflict === c}
                onChange={() => setConflict(c)}
                disabled={running}
              />{' '}
              {c === 'rename' ? 'umbenennen' : c === 'overwrite' ? 'überschreiben' : 'überspringen'}
            </label>
          ))}
        </div>

        {progress && (
          <div className="progress">
            <div className="progress-bar">
              <div className="progress-fill" style={{ width: `${Math.min(100, pct)}%` }} />
            </div>
            <div className="progress-meta">
              {progress.filesDone}/{progress.filesTotal} Dateien ·{' '}
              {formatBytes(progress.bytesDone)} / {formatBytes(progress.bytesTotal)} ·{' '}
              {(progress.elapsedMs / 1000).toFixed(1)}s
              {progress.errors ? ` · ${progress.errors} Fehler` : ''}
            </div>
          </div>
        )}

        <div className="modal-actions">
          <button className="btn ghost" onClick={onClose} disabled={running}>
            Abbrechen
          </button>
          <button
            className="btn primary"
            disabled={!dest || running}
            onClick={() => onConfirm(dest, preserve, conflict)}
          >
            {mode === 'copy' ? 'Kopieren' : 'Verschieben'}
          </button>
        </div>
      </div>
    </div>
  );
}

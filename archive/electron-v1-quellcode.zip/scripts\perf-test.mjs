// Perf test: scan node_modules with multiple workers in parallel.
// Measures aggregate throughput.
import { Worker } from 'node:worker_threads';
import { readdirSync, lstatSync } from 'node:fs';
import path from 'node:path';
import os from 'node:os';

const target = path.resolve(process.argv[2] || 'node_modules');
const scanWorkerPath = path.resolve('dist-electron/scan-worker.cjs');
console.log('Target:', target);

const t0 = Date.now();
const topLevelDirs = readdirSync(target, { withFileTypes: true })
  .filter((d) => d.isDirectory())
  .map((d) => path.join(target, d.name));
console.log(`Top-level dirs: ${topLevelDirs.length}`);

const cpuCount = Math.min(os.cpus().length, 16);
const workerCount = Math.min(cpuCount, topLevelDirs.length);
console.log(`Spawning ${workerCount} workers across ${cpuCount} cores`);

const buckets = Array.from({ length: workerCount }, () => []);
topLevelDirs.forEach((d, i) => buckets[i % workerCount].push(d));

let totalScanned = 0;
let totalBytes = 0;
let totalErrors = 0;
let entriesEmitted = 0;

const promises = buckets.map((bucket, idx) =>
  new Promise((resolve, reject) => {
    const w = new Worker(scanWorkerPath);
    w.on('message', (m) => {
      if (m.type === 'entries') entriesEmitted += m.entries.length;
      else if (m.type === 'done') {
        totalScanned += m.scanned;
        totalBytes += m.bytes;
        totalErrors += m.errors;
        w.terminate();
      }
    });
    w.on('error', reject);
    w.on('exit', resolve);
    w.postMessage({
      type: 'scan',
      startDirs: bucket,
      startDepth: 1,
      opts: { root: target, followSymlinks: false, includeHidden: true, includeSystem: true },
    });
  }),
);

await Promise.all(promises);
const elapsed = Date.now() - t0;
console.log('---');
console.log(`Scanned:  ${totalScanned.toLocaleString()} entries`);
console.log(`Bytes:    ${(totalBytes / 1024 / 1024 / 1024).toFixed(2)} GB`);
console.log(`Errors:   ${totalErrors}`);
console.log(`Time:     ${elapsed} ms`);
console.log(`Rate:     ${((totalScanned / elapsed) * 1000).toLocaleString(undefined, { maximumFractionDigits: 0 })} entries/sec`);
console.log(`Entries emitted via batches: ${entriesEmitted.toLocaleString()}`);

import React from 'react';
import type { CopyProgress, ScanProgress } from '../../shared/types';
import { formatBytes } from '../../shared/sort';

type Props = {
  progress: ScanProgress;
  scanState: 'idle' | 'scanning' | 'done' | 'error';
  viewCount: number;
  totalCount: number;
  selectionCount: number;
  errorMsg?: string;
  copyProgress?: CopyProgress;
  appVersion: string;
  updateStatus?: { state: string; version?: string; percent?: number; message?: string };
};

function rate(scanned: number, ms: number): string {
  if (!ms) return '–';
  const perSec = (scanned / ms) * 1000;
  if (perSec >= 1000) return `${(perSec / 1000).toFixed(1)}k Einträge/s`;
  return `${perSec.toFixed(0)} Einträge/s`;
}

function updaterLabel(u?: Props['updateStatus']) {
  if (!u) return null;
  switch (u.state) {
    case 'checking': return 'Update-Check…';
    case 'available': return `Update ${u.version} verfügbar`;
    case 'downloading': return `Update lädt ${(u.percent ?? 0).toFixed(0)}%`;
    case 'downloaded': return `Update ${u.version} bereit (Neustart)`;
    case 'idle': return 'Aktuell';
    case 'error': return `Update-Fehler: ${u.message ?? ''}`;
    default: return null;
  }
}

export function StatusBar(p: Props) {
  const u = updaterLabel(p.updateStatus);
  return (
    <div className="statusbar">
      <span>
        {p.scanState === 'scanning' ? '⟳ Scan läuft…' : p.scanState === 'done' ? '✓ Bereit' : ''}
      </span>
      <span className="dim">
        {p.progress.scanned.toLocaleString()} gescannt · {formatBytes(p.progress.bytes)} ·{' '}
        {(p.progress.elapsedMs / 1000).toFixed(1)}s · {rate(p.progress.scanned, p.progress.elapsedMs)}
        {p.progress.errors ? ` · ${p.progress.errors} Fehler` : ''}
      </span>
      {p.progress.currentPath && p.scanState === 'scanning' && (
        <span className="path-sample" title={p.progress.currentPath}>
          {p.progress.currentPath}
        </span>
      )}
      <span className="grow" />
      {p.copyProgress && !p.copyProgress.done && (
        <span>
          Kopieren: {p.copyProgress.filesDone}/{p.copyProgress.filesTotal} ·{' '}
          {formatBytes(p.copyProgress.bytesDone)}/{formatBytes(p.copyProgress.bytesTotal)}
        </span>
      )}
      <span className="dim">
        Auswahl: {p.selectionCount.toLocaleString()} · Sicht: {p.viewCount.toLocaleString()} / {p.totalCount.toLocaleString()}
      </span>
      {p.errorMsg && <span className="err">⚠ {p.errorMsg}</span>}
      {u && <span className="dim">· {u}</span>}
      <span className="dim">v{p.appVersion}</span>
    </div>
  );
}

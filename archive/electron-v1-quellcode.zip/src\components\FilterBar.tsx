import React from 'react';
import type { FilterDef } from '../../shared/types';

type Props = {
  filter: FilterDef;
  onChange: (f: FilterDef) => void;
  entryCount: number;
  viewCount: number;
};

function parseSize(input: string): number | undefined {
  if (!input) return undefined;
  const m = input.trim().toLowerCase().match(/^(\d+(?:[.,]\d+)?)\s*(kb|mb|gb|tb|b)?$/);
  if (!m) return undefined;
  const v = parseFloat(m[1].replace(',', '.'));
  const unit = m[2] || 'b';
  const mul = unit === 'b' ? 1 : unit === 'kb' ? 1024 : unit === 'mb' ? 1024 ** 2 : unit === 'gb' ? 1024 ** 3 : 1024 ** 4;
  return Math.round(v * mul);
}

function dateToMs(s: string): number | undefined {
  if (!s) return undefined;
  const t = Date.parse(s);
  return isNaN(t) ? undefined : t;
}

function msToDateInput(ms: number | undefined): string {
  if (!ms) return '';
  const d = new Date(ms);
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  return `${yyyy}-${mm}-${dd}`;
}

function msToBytesInput(b: number | undefined): string {
  if (!b) return '';
  const units: [number, string][] = [
    [1024 ** 4, 'TB'],
    [1024 ** 3, 'GB'],
    [1024 ** 2, 'MB'],
    [1024, 'KB'],
  ];
  for (const [div, u] of units) {
    if (b >= div) {
      const v = b / div;
      return `${v >= 100 ? v.toFixed(0) : v.toFixed(1)} ${u}`;
    }
  }
  return `${b} B`;
}

export function FilterBar({ filter, onChange, entryCount, viewCount }: Props) {
  const update = (patch: Partial<FilterDef>) => onChange({ ...filter, ...patch });
  const updateSize = (which: 'min' | 'max', val: string) => {
    const v = parseSize(val);
    update({ size: { ...filter.size, [which]: v } });
  };
  const updateDate = (
    field: 'mtime' | 'birthtime',
    which: 'min' | 'max',
    val: string,
  ) => {
    const v = dateToMs(val);
    const adj = which === 'max' && v !== undefined ? v + 24 * 3600 * 1000 - 1 : v;
    update({ [field]: { ...filter[field], [which]: adj } } as any);
  };

  const reset = () =>
    onChange({
      textMode: 'substring',
      includeDirs: true,
      includeFiles: true,
      includeHidden: false,
      includeSystem: false,
    });

  return (
    <div className="filterbar">
      <div className="filter-row">
        <select
          value={filter.textMode || 'substring'}
          onChange={(e) => update({ textMode: e.target.value as any })}
          title="Suchmodus"
        >
          <option value="substring">enthält</option>
          <option value="regex">RegExp</option>
          <option value="glob">Glob</option>
        </select>
        <input
          className="grow"
          placeholder={
            filter.textMode === 'regex'
              ? 'Regex z.B. \\.log$'
              : filter.textMode === 'glob'
              ? 'Glob z.B. **/build/**'
              : 'Suche im Namen…'
          }
          value={
            filter.textMode === 'regex'
              ? filter.regex ?? ''
              : filter.textMode === 'glob'
              ? filter.glob ?? ''
              : filter.text ?? ''
          }
          onChange={(e) => {
            const v = e.target.value;
            if (filter.textMode === 'regex') update({ regex: v });
            else if (filter.textMode === 'glob') update({ glob: v });
            else update({ text: v });
          }}
        />

        <input
          placeholder="Endungen z.B. jpg,png,docx"
          value={(filter.extensions || []).join(',')}
          onChange={(e) => {
            const v = e.target.value;
            const parts = v
              .split(/[,\s]+/)
              .map((s) => s.trim().toLowerCase().replace(/^\./, ''))
              .filter(Boolean);
            update({ extensions: parts });
          }}
          style={{ width: 220 }}
        />
      </div>

      <div className="filter-row">
        <span className="lbl">Größe:</span>
        <input
          placeholder="≥ z.B. 10 MB"
          defaultValue={msToBytesInput(filter.size?.min)}
          onBlur={(e) => updateSize('min', e.target.value)}
          onKeyDown={(e) => { if (e.key === 'Enter') (e.target as HTMLInputElement).blur(); }}
          style={{ width: 130 }}
        />
        <input
          placeholder="≤ z.B. 1 GB"
          defaultValue={msToBytesInput(filter.size?.max)}
          onBlur={(e) => updateSize('max', e.target.value)}
          onKeyDown={(e) => { if (e.key === 'Enter') (e.target as HTMLInputElement).blur(); }}
          style={{ width: 130 }}
        />

        <span className="lbl">Geändert:</span>
        <input
          type="date"
          value={msToDateInput(filter.mtime?.min)}
          onChange={(e) => updateDate('mtime', 'min', e.target.value)}
        />
        <input
          type="date"
          value={msToDateInput(filter.mtime?.max ? filter.mtime.max - (24 * 3600 * 1000 - 1) : undefined)}
          onChange={(e) => updateDate('mtime', 'max', e.target.value)}
        />

        <span className="lbl">Erstellt:</span>
        <input
          type="date"
          value={msToDateInput(filter.birthtime?.min)}
          onChange={(e) => updateDate('birthtime', 'min', e.target.value)}
        />
        <input
          type="date"
          value={msToDateInput(filter.birthtime?.max ? filter.birthtime.max - (24 * 3600 * 1000 - 1) : undefined)}
          onChange={(e) => updateDate('birthtime', 'max', e.target.value)}
        />

        <span className="grow" />
        <button className="btn ghost" onClick={reset} title="Alle Filter zurücksetzen">
          Reset
        </button>
      </div>

      <div className="filter-row tight">
        <label>
          <input
            type="checkbox"
            checked={filter.includeFiles}
            onChange={(e) => update({ includeFiles: e.target.checked })}
          />{' '}
          Dateien
        </label>
        <label>
          <input
            type="checkbox"
            checked={filter.includeDirs}
            onChange={(e) => update({ includeDirs: e.target.checked })}
          />{' '}
          Ordner
        </label>
        <label>
          <input
            type="checkbox"
            checked={filter.includeHidden}
            onChange={(e) => update({ includeHidden: e.target.checked })}
          />{' '}
          versteckt
        </label>
        <label>
          <input
            type="checkbox"
            checked={filter.includeSystem}
            onChange={(e) => update({ includeSystem: e.target.checked })}
          />{' '}
          System
        </label>

        <span className="grow" />
        <span className="counts">
          {viewCount.toLocaleString()} / {entryCount.toLocaleString()} Einträge
        </span>
      </div>
    </div>
  );
}

import React, { useEffect, useState } from 'react';

type Props = {
  currentPath: string;
  onPick: (p: string) => void;
};

export function Sidebar({ currentPath, onPick }: Props) {
  const [drives, setDrives] = useState<string[]>([]);
  const [home, setHome] = useState<string>('');
  const [recent, setRecent] = useState<string[]>(() => {
    try {
      return JSON.parse(localStorage.getItem('recent') || '[]');
    } catch {
      return [];
    }
  });

  useEffect(() => {
    window.api.system.listDrives().then(setDrives);
    window.api.system.homeDir().then(setHome);
  }, []);

  useEffect(() => {
    if (!currentPath) return;
    setRecent((prev) => {
      const next = [currentPath, ...prev.filter((p) => p !== currentPath)].slice(0, 10);
      localStorage.setItem('recent', JSON.stringify(next));
      return next;
    });
  }, [currentPath]);

  const quick = home
    ? [
        { label: 'Home', path: home },
        { label: 'Desktop', path: `${home}/Desktop` },
        { label: 'Documents', path: `${home}/Documents` },
        { label: 'Downloads', path: `${home}/Downloads` },
        { label: 'Pictures', path: `${home}/Pictures` },
        { label: 'Music', path: `${home}/Music` },
        { label: 'Videos', path: `${home}/Videos` },
      ]
    : [];

  return (
    <aside className="sidebar">
      <div className="side-section">
        <div className="side-title">Schnellzugriff</div>
        <ul className="side-list">
          {quick.map((q) => (
            <li
              key={q.path}
              className={currentPath === q.path ? 'active' : ''}
              onClick={() => onPick(q.path)}
              title={q.path}
            >
              {q.label}
            </li>
          ))}
        </ul>
      </div>

      {drives.length > 0 && (
        <div className="side-section">
          <div className="side-title">Laufwerke</div>
          <ul className="side-list">
            {drives.map((d) => (
              <li
                key={d}
                className={currentPath === d ? 'active' : ''}
                onClick={() => onPick(d)}
              >
                {d}
              </li>
            ))}
          </ul>
        </div>
      )}

      {recent.length > 0 && (
        <div className="side-section">
          <div className="side-title">Zuletzt</div>
          <ul className="side-list">
            {recent.map((r) => (
              <li
                key={r}
                className={currentPath === r ? 'active' : ''}
                onClick={() => onPick(r)}
                title={r}
              >
                {r.split('/').filter(Boolean).pop() || r}
              </li>
            ))}
          </ul>
        </div>
      )}
    </aside>
  );
}

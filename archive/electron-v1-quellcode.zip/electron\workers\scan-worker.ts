import { parentPort, workerData } from 'node:worker_threads';
import { readdirSync, lstatSync } from 'node:fs';
import path from 'node:path';
import type { FileEntry, ScanOptions } from '../../shared/types';

const BATCH_SIZE = 512;
const FLUSH_INTERVAL_MS = 80;

const port = parentPort;
if (!port) throw new Error('scan-worker must be run as a worker thread');

let batch: FileEntry[] = [];
let scanned = 0;
let bytes = 0;
let errors = 0;
let lastFlushAt = Date.now();
let lastSampleAt = 0;

function flush(force: boolean) {
  if (!batch.length && !force) return;
  if (force || batch.length >= BATCH_SIZE || Date.now() - lastFlushAt > FLUSH_INTERVAL_MS) {
    if (batch.length) {
      port!.postMessage({ type: 'entries', entries: batch });
      batch = [];
    }
    port!.postMessage({ type: 'progress', scanned, bytes, errors });
    lastFlushAt = Date.now();
  }
}

function makeEntry(
  full: string,
  parent: string,
  name: string,
  isDir: boolean,
  isSymlink: boolean,
  size: number,
  mtimeMs: number,
  birthtimeMs: number,
  depth: number,
): FileEntry {
  const ext = isDir ? '' : path.extname(name).slice(1).toLowerCase();
  return {
    path: full.replace(/\\/g, '/'),
    parent: parent.replace(/\\/g, '/'),
    name,
    ext,
    size,
    mtimeMs,
    birthtimeMs,
    isDir,
    isSymlink,
    hidden: name.startsWith('.'),
    system: false,
    depth,
  };
}

function walk(dir: string, depth: number, opts: ScanOptions, sampler?: { current: string }) {
  let dirents: import('node:fs').Dirent[];
  try {
    dirents = readdirSync(dir, { withFileTypes: true });
  } catch {
    errors++;
    return;
  }

  for (const d of dirents) {
    const full = dir + (dir.endsWith(path.sep) ? '' : path.sep) + d.name;
    const isSymlink = d.isSymbolicLink();
    const isDir = d.isDirectory();

    let size = 0;
    let mtimeMs = 0;
    let birthtimeMs = 0;
    try {
      const st = lstatSync(full);
      size = Number(st.size);
      mtimeMs = st.mtimeMs;
      birthtimeMs = st.birthtimeMs || st.ctimeMs;
    } catch {
      errors++;
      continue;
    }

    if (sampler && Date.now() - lastSampleAt > 200) {
      lastSampleAt = Date.now();
      sampler.current = full;
      port!.postMessage({ type: 'sample', currentPath: full });
    }

    const entry = makeEntry(full, dir, d.name, isDir, isSymlink, size, mtimeMs, birthtimeMs, depth);
    if (!opts.includeHidden && entry.hidden) continue;

    batch.push(entry);
    scanned++;
    if (!isDir) bytes += size;
    flush(false);

    if (isDir) {
      const recurse = !isSymlink || opts.followSymlinks;
      const within = opts.maxDepth === undefined || depth + 1 <= opts.maxDepth;
      if (recurse && within) walk(full, depth + 1, opts, sampler);
    }
  }
}

port.on('message', (msg: any) => {
  if (msg.type !== 'scan') return;
  const startDirs: string[] = msg.startDirs;
  const startDepth: number = msg.startDepth ?? 1;
  const opts: ScanOptions = msg.opts;
  const start = Date.now();
  const sampler = { current: '' };
  for (const d of startDirs) walk(d, startDepth, opts, sampler);
  flush(true);
  port.postMessage({
    type: 'done',
    scanned,
    bytes,
    errors,
    elapsedMs: Date.now() - start,
  });
});

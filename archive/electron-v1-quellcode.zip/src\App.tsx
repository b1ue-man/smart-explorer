import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { CopyOptions, CopyProgress, FileEntry, FilterDef, ScanProgress, SortDir, SortKey } from '../shared/types';
import { compileFilter, defaultFilter } from '../shared/filter';
import { compareEntries } from '../shared/sort';
import { Sidebar } from './components/Sidebar';
import { Toolbar } from './components/Toolbar';
import { FilterBar } from './components/FilterBar';
import { FileGrid } from './components/FileGrid';
import { StatusBar } from './components/StatusBar';
import { CopyDialog } from './components/CopyDialog';
import { SummaryPanel } from './components/SummaryPanel';

export type ScanState = 'idle' | 'scanning' | 'done' | 'error';

export type AppState = {
  rootPath: string;
  scanState: ScanState;
  entries: FileEntry[];
  progress: ScanProgress;
  filter: FilterDef;
  sortKey: SortKey;
  sortDir: SortDir;
  selection: Set<string>;
  copyProgress?: CopyProgress;
  copyDialogOpen: boolean;
  copyMode: 'copy' | 'move';
  errorMsg?: string;
  showFilters: boolean;
  showSummary: boolean;
  appVersion: string;
  updateStatus?: { state: string; version?: string; percent?: number; message?: string };
};

const initialState: AppState = {
  rootPath: '',
  scanState: 'idle',
  entries: [],
  progress: { scanned: 0, bytes: 0, errors: 0, elapsedMs: 0, done: false },
  filter: defaultFilter(),
  sortKey: 'path',
  sortDir: 'asc',
  selection: new Set(),
  copyDialogOpen: false,
  copyMode: 'copy',
  showFilters: true,
  showSummary: false,
  appVersion: '0.0.0',
};

export function App() {
  const [state, setState] = useState<AppState>(initialState);
  const scanJob = useRef<{ cancel: () => void; cleanup: () => void } | null>(null);
  const copyJob = useRef<{ cancel: () => void; cleanup: () => void } | null>(null);

  // we accumulate incoming entry batches in a ref, then flush to React state
  // periodically — avoids re-render storms during scans of large folders.
  const pending = useRef<FileEntry[]>([]);
  const flushTimer = useRef<number | null>(null);

  useEffect(() => {
    window.api.system.appVersion().then((v) => setState((s) => ({ ...s, appVersion: v })));
    const off = window.api.system.onUpdateStatus((u) => setState((s) => ({ ...s, updateStatus: u })));
    return off;
  }, []);

  const scheduleFlush = useCallback(() => {
    if (flushTimer.current !== null) return;
    flushTimer.current = window.setTimeout(() => {
      flushTimer.current = null;
      const batch = pending.current;
      pending.current = [];
      if (!batch.length) return;
      setState((s) => ({ ...s, entries: s.entries.concat(batch) }));
    }, 80);
  }, []);

  const startScan = useCallback(
    (rootPath: string) => {
      if (!rootPath) return;
      // cancel any prior job
      if (scanJob.current) {
        scanJob.current.cancel();
        scanJob.current.cleanup();
        scanJob.current = null;
      }
      pending.current = [];
      setState((s) => ({
        ...s,
        rootPath,
        scanState: 'scanning',
        entries: [],
        progress: { scanned: 0, bytes: 0, errors: 0, elapsedMs: 0, done: false },
        selection: new Set(),
        errorMsg: undefined,
      }));

      const job = window.api.scan.start(
        {
          root: rootPath,
          followSymlinks: false,
          includeHidden: state.filter.includeHidden,
          includeSystem: state.filter.includeSystem,
        },
        {
          onEntries: (entries) => {
            pending.current.push(...entries);
            scheduleFlush();
          },
          onProgress: (p) => {
            setState((s) => ({ ...s, progress: p }));
          },
          onError: (msg) => {
            setState((s) => ({ ...s, errorMsg: msg }));
          },
          onDone: () => {
            // final flush
            if (pending.current.length) {
              const batch = pending.current;
              pending.current = [];
              setState((s) => ({ ...s, entries: s.entries.concat(batch), scanState: 'done' }));
            } else {
              setState((s) => ({ ...s, scanState: 'done' }));
            }
          },
        },
      );
      scanJob.current = job;
    },
    [scheduleFlush, state.filter.includeHidden, state.filter.includeSystem],
  );

  const cancelScan = useCallback(() => {
    if (scanJob.current) {
      scanJob.current.cancel();
      scanJob.current.cleanup();
      scanJob.current = null;
    }
    setState((s) => ({ ...s, scanState: 'done' }));
  }, []);

  // ── Derived view: filtered + sorted ────────────────────────────────────────
  const compiledFilter = useMemo(() => compileFilter(state.filter), [state.filter]);
  const rootPrefix = useMemo(
    () => (state.rootPath ? state.rootPath.replace(/\\/g, '/').replace(/\/$/, '') : ''),
    [state.rootPath],
  );

  const view = useMemo(() => {
    const filtered = state.entries.filter((e) => compiledFilter(e, rootPrefix));
    filtered.sort((a, b) => compareEntries(a, b, state.sortKey, state.sortDir));
    return filtered;
  }, [state.entries, compiledFilter, rootPrefix, state.sortKey, state.sortDir]);

  // ── Selection helpers ─────────────────────────────────────────────────────
  const toggleSelect = useCallback((path: string, mode: 'set' | 'toggle' | 'add' | 'range', anchor?: string) => {
    setState((s) => {
      const sel = new Set(s.selection);
      if (mode === 'set') {
        sel.clear();
        sel.add(path);
      } else if (mode === 'toggle') {
        if (sel.has(path)) sel.delete(path);
        else sel.add(path);
      } else if (mode === 'add') {
        sel.add(path);
      } else if (mode === 'range') {
        // shift-click: select range in current view
        const idxA = anchor ? view.findIndex((e) => e.path === anchor) : -1;
        const idxB = view.findIndex((e) => e.path === path);
        if (idxA >= 0 && idxB >= 0) {
          const lo = Math.min(idxA, idxB);
          const hi = Math.max(idxA, idxB);
          for (let i = lo; i <= hi; i++) sel.add(view[i].path);
        } else {
          sel.add(path);
        }
      }
      return { ...s, selection: sel };
    });
  }, [view]);

  const selectAll = useCallback(() => {
    setState((s) => ({ ...s, selection: new Set(view.map((e) => e.path)) }));
  }, [view]);

  const clearSelection = useCallback(() => {
    setState((s) => ({ ...s, selection: new Set() }));
  }, []);

  const setFilter = useCallback((f: FilterDef) => {
    setState((s) => ({ ...s, filter: f }));
  }, []);

  const setSort = useCallback((key: SortKey) => {
    setState((s) =>
      s.sortKey === key
        ? { ...s, sortDir: s.sortDir === 'asc' ? 'desc' : 'asc' }
        : { ...s, sortKey: key, sortDir: 'asc' },
    );
  }, []);

  // ── File operations ───────────────────────────────────────────────────────
  const openCopyDialog = (mode: 'copy' | 'move') =>
    setState((s) => ({ ...s, copyDialogOpen: true, copyMode: mode }));

  const startCopy = useCallback(
    async (dest: string, preserveStructure: boolean, conflict: 'skip' | 'overwrite' | 'rename') => {
      const selected = state.entries.filter((e) => state.selection.has(e.path));
      if (!selected.length) return;
      if (copyJob.current) {
        copyJob.current.cancel();
        copyJob.current.cleanup();
      }
      const opts: CopyOptions = {
        entries: selected,
        root: state.rootPath,
        dest,
        preserveStructure,
        conflict,
        move: state.copyMode === 'move',
      };
      const job = window.api.copy.start(opts, {
        onProgress: (p) => setState((s) => ({ ...s, copyProgress: p })),
        onDone: (errs) => {
          setState((s) => ({
            ...s,
            copyProgress: { ...(s.copyProgress ?? { filesDone: 0, filesTotal: 0, bytesDone: 0, bytesTotal: 0, elapsedMs: 0, errors: errs.length, done: true }), done: true, errors: errs.length },
            copyDialogOpen: false,
          }));
        },
      });
      copyJob.current = job;
    },
    [state.entries, state.selection, state.copyMode, state.rootPath],
  );

  const trashSelection = useCallback(async () => {
    const paths = Array.from(state.selection);
    if (!paths.length) return;
    const ok = window.confirm(`In den Papierkorb verschieben? (${paths.length} Einträge)`);
    if (!ok) return;
    const r = await window.api.files.trash(paths);
    setState((s) => ({
      ...s,
      entries: s.entries.filter((e) => !s.selection.has(e.path)),
      selection: new Set(),
      errorMsg: r.errors.length ? `${r.errors.length} Fehler beim Löschen` : undefined,
    }));
  }, [state.selection]);

  const copyPathsToClipboard = useCallback(() => {
    const paths = Array.from(state.selection);
    if (paths.length) window.api.clipboard.writePaths(paths);
  }, [state.selection]);

  const openInExplorer = useCallback((path: string) => {
    window.api.shell.openInExplorer(path);
  }, []);

  // ── Keyboard shortcuts ────────────────────────────────────────────────────
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement)?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA') return;
      if (e.ctrlKey && e.key === 'a') {
        e.preventDefault();
        selectAll();
      } else if (e.ctrlKey && e.key === 'c') {
        e.preventDefault();
        copyPathsToClipboard();
      } else if (e.key === 'Delete') {
        e.preventDefault();
        trashSelection();
      } else if (e.key === 'Escape') {
        clearSelection();
      } else if (e.key === 'F5') {
        if (state.rootPath) startScan(state.rootPath);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [selectAll, copyPathsToClipboard, trashSelection, clearSelection, state.rootPath, startScan]);

  return (
    <div className="app">
      <Toolbar
        path={state.rootPath}
        scanning={state.scanState === 'scanning'}
        onPickFolder={async () => {
          const p = await window.api.pickFolder(state.rootPath || undefined);
          if (p) startScan(p);
        }}
        onPathChange={(p) => setState((s) => ({ ...s, rootPath: p }))}
        onScan={() => startScan(state.rootPath)}
        onCancel={cancelScan}
        onCopy={() => openCopyDialog('copy')}
        onMove={() => openCopyDialog('move')}
        onTrash={trashSelection}
        onCopyPaths={copyPathsToClipboard}
        selectionCount={state.selection.size}
        toggleFilters={() => setState((s) => ({ ...s, showFilters: !s.showFilters }))}
        toggleSummary={() => setState((s) => ({ ...s, showSummary: !s.showSummary }))}
      />

      <div className="main-row">
        <Sidebar
          currentPath={state.rootPath}
          onPick={(p) => startScan(p)}
        />

        <div className="content">
          {state.showFilters && (
            <FilterBar
              filter={state.filter}
              onChange={setFilter}
              entryCount={state.entries.length}
              viewCount={view.length}
            />
          )}

          <div className="grid-and-summary">
            <FileGrid
              rows={view}
              selection={state.selection}
              sortKey={state.sortKey}
              sortDir={state.sortDir}
              onSort={setSort}
              onSelect={toggleSelect}
              onOpen={(e) => {
                if (e.isDir) {
                  startScan(e.path);
                } else {
                  window.api.shell.openPath(e.path);
                }
              }}
              onContextOpen={openInExplorer}
              rootPrefix={rootPrefix}
            />

            {state.showSummary && (
              <SummaryPanel entries={view} />
            )}
          </div>
        </div>
      </div>

      <StatusBar
        progress={state.progress}
        scanState={state.scanState}
        viewCount={view.length}
        totalCount={state.entries.length}
        selectionCount={state.selection.size}
        errorMsg={state.errorMsg}
        copyProgress={state.copyProgress}
        appVersion={state.appVersion}
        updateStatus={state.updateStatus}
      />

      {state.copyDialogOpen && (
        <CopyDialog
          mode={state.copyMode}
          selectionCount={state.selection.size}
          onClose={() => setState((s) => ({ ...s, copyDialogOpen: false }))}
          onConfirm={startCopy}
          progress={state.copyProgress}
        />
      )}
    </div>
  );
}

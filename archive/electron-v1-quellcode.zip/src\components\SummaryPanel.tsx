import React, { useMemo } from 'react';
import type { FileEntry } from '../../shared/types';
import { formatBytes, formatDate } from '../../shared/sort';

type Props = {
  entries: FileEntry[];
};

export function SummaryPanel({ entries }: Props) {
  const summary = useMemo(() => {
    let totalFiles = 0;
    let totalDirs = 0;
    let totalBytes = 0;
    const byExt: Record<string, { count: number; bytes: number }> = {};
    let oldest = Number.POSITIVE_INFINITY;
    let newest = 0;
    const top: FileEntry[] = [];
    for (const e of entries) {
      if (e.isDir) totalDirs++;
      else {
        totalFiles++;
        totalBytes += e.size;
        const k = e.ext || '(none)';
        const b = (byExt[k] ||= { count: 0, bytes: 0 });
        b.count++;
        b.bytes += e.size;
        if (e.mtimeMs && e.mtimeMs < oldest) oldest = e.mtimeMs;
        if (e.mtimeMs > newest) newest = e.mtimeMs;
        // maintain top-10 by size
        if (top.length < 10) {
          top.push(e);
          top.sort((a, b) => b.size - a.size);
        } else if (e.size > top[top.length - 1].size) {
          top[top.length - 1] = e;
          top.sort((a, b) => b.size - a.size);
        }
      }
    }
    const exts = Object.entries(byExt)
      .sort((a, b) => b[1].bytes - a[1].bytes)
      .slice(0, 20);
    return { totalFiles, totalDirs, totalBytes, exts, oldest, newest, top };
  }, [entries]);

  return (
    <aside className="summary-panel">
      <div className="summary-section">
        <div className="summary-title">Zusammenfassung</div>
        <div className="kv"><span>Dateien</span><b>{summary.totalFiles.toLocaleString()}</b></div>
        <div className="kv"><span>Ordner</span><b>{summary.totalDirs.toLocaleString()}</b></div>
        <div className="kv"><span>Gesamtgröße</span><b>{formatBytes(summary.totalBytes)}</b></div>
        {isFinite(summary.oldest) && (
          <div className="kv"><span>Älteste</span><b>{formatDate(summary.oldest)}</b></div>
        )}
        {summary.newest > 0 && (
          <div className="kv"><span>Neueste</span><b>{formatDate(summary.newest)}</b></div>
        )}
      </div>

      <div className="summary-section">
        <div className="summary-title">Top-Dateitypen</div>
        <div className="ext-table">
          {summary.exts.map(([k, v]) => (
            <div className="ext-row" key={k}>
              <span className="ext-key">{k}</span>
              <span className="ext-count">{v.count.toLocaleString()}</span>
              <span className="ext-bytes">{formatBytes(v.bytes)}</span>
            </div>
          ))}
          {summary.exts.length === 0 && <div className="dim">keine Daten</div>}
        </div>
      </div>

      <div className="summary-section">
        <div className="summary-title">Größte Dateien</div>
        <ul className="big-list">
          {summary.top.map((t) => (
            <li key={t.path} title={t.path}>
              <b>{formatBytes(t.size)}</b> · {t.name}
            </li>
          ))}
        </ul>
      </div>
    </aside>
  );
}

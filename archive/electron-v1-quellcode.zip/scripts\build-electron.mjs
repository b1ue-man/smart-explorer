import { build } from 'esbuild';
import { mkdir, rm } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, '..');
const outdir = path.join(root, 'dist-electron');

await rm(outdir, { recursive: true, force: true });
await mkdir(outdir, { recursive: true });

const common = {
  bundle: true,
  platform: 'node',
  format: 'cjs',
  target: 'node20',
  sourcemap: false,
  logLevel: 'info',
  external: ['electron', 'electron-updater', 'trash'],
};

await Promise.all([
  build({
    ...common,
    entryPoints: [path.join(root, 'electron/main.ts')],
    outfile: path.join(outdir, 'main.cjs'),
  }),
  build({
    ...common,
    entryPoints: [path.join(root, 'electron/preload.ts')],
    outfile: path.join(outdir, 'preload.cjs'),
  }),
  build({
    ...common,
    entryPoints: [path.join(root, 'electron/workers/scan-worker.ts')],
    outfile: path.join(outdir, 'scan-worker.cjs'),
  }),
  build({
    ...common,
    entryPoints: [path.join(root, 'electron/workers/copy-worker.ts')],
    outfile: path.join(outdir, 'copy-worker.cjs'),
  }),
]);

console.log('Electron bundles built into', outdir);

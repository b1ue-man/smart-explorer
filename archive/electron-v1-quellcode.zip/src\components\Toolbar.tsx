import React from 'react';

type Props = {
  path: string;
  scanning: boolean;
  onPickFolder: () => void;
  onPathChange: (p: string) => void;
  onScan: () => void;
  onCancel: () => void;
  onCopy: () => void;
  onMove: () => void;
  onTrash: () => void;
  onCopyPaths: () => void;
  selectionCount: number;
  toggleFilters: () => void;
  toggleSummary: () => void;
};

export function Toolbar(p: Props) {
  return (
    <div className="toolbar">
      <button className="btn primary" onClick={p.onPickFolder} title="Ordner auswählen">
        Ordner…
      </button>
      <input
        className="path-input"
        value={p.path}
        placeholder="Pfad eingeben oder Ordner wählen…"
        onChange={(e) => p.onPathChange(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === 'Enter') p.onScan();
        }}
      />
      {p.scanning ? (
        <button className="btn warn" onClick={p.onCancel}>
          Stop
        </button>
      ) : (
        <button className="btn primary" onClick={p.onScan} disabled={!p.path}>
          Scannen
        </button>
      )}

      <span className="sep" />

      <button
        className="btn"
        onClick={p.onCopy}
        disabled={p.selectionCount === 0}
        title="Auswahl kopieren (mit Ordnerstruktur)"
      >
        Kopieren ({p.selectionCount})
      </button>
      <button
        className="btn"
        onClick={p.onMove}
        disabled={p.selectionCount === 0}
        title="Auswahl verschieben (mit Ordnerstruktur)"
      >
        Verschieben
      </button>
      <button
        className="btn"
        onClick={p.onTrash}
        disabled={p.selectionCount === 0}
        title="Auswahl in Papierkorb"
      >
        Papierkorb
      </button>
      <button
        className="btn"
        onClick={p.onCopyPaths}
        disabled={p.selectionCount === 0}
        title="Pfade in Zwischenablage"
      >
        Pfade
      </button>

      <span className="grow" />

      <button className="btn ghost" onClick={p.toggleFilters} title="Filter ein/aus">
        Filter
      </button>
      <button className="btn ghost" onClick={p.toggleSummary} title="Zusammenfassung">
        Summe
      </button>
    </div>
  );
}

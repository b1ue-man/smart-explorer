import type { BrowserWindow } from 'electron';

/**
 * Wires up electron-updater to check on launch and at a daily interval.
 * Updates only auto-download; install happens on app quit.
 *
 * Falls back silently if electron-updater isn't bundled (e.g. in an unsigned
 * sideloaded build without a feed). Production releases publish to GitHub via
 * the `publish` field in package.json's `build` block.
 */
export function setupAutoUpdate(getWin: () => BrowserWindow | null) {
  let autoUpdater: any;
  try {
    // dynamic require so dev / unbuilt runs don't crash
    autoUpdater = require('electron-updater').autoUpdater;
  } catch {
    return;
  }
  autoUpdater.autoDownload = true;
  autoUpdater.autoInstallOnAppQuit = true;

  const send = (channel: string, payload: any) => {
    const w = getWin();
    if (w && !w.isDestroyed()) w.webContents.send(channel, payload);
  };

  autoUpdater.on('checking-for-update', () => send('updater:status', { state: 'checking' }));
  autoUpdater.on('update-available', (info: any) =>
    send('updater:status', { state: 'available', version: info.version }),
  );
  autoUpdater.on('update-not-available', () => send('updater:status', { state: 'idle' }));
  autoUpdater.on('download-progress', (p: any) =>
    send('updater:status', { state: 'downloading', percent: p.percent }),
  );
  autoUpdater.on('update-downloaded', (info: any) =>
    send('updater:status', { state: 'downloaded', version: info.version }),
  );
  autoUpdater.on('error', (err: Error) =>
    send('updater:status', { state: 'error', message: err.message }),
  );

  const tryCheck = () => {
    autoUpdater.checkForUpdates().catch(() => {
      /* offline / no feed → ignore */
    });
  };

  setTimeout(tryCheck, 5_000);
  setInterval(tryCheck, 6 * 60 * 60 * 1000); // every 6h
}

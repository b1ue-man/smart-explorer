import type { FileEntry, FilterDef, RangeFilter } from './types';

function inRange(v: number, r?: RangeFilter): boolean {
  if (!r) return true;
  if (r.min !== undefined && v < r.min) return false;
  if (r.max !== undefined && v > r.max) return false;
  return true;
}

/**
 * Convert a glob pattern to a RegExp. Supports `*`, `**`, `?`, character classes,
 * and forward-slash path separators.
 */
export function globToRegex(glob: string): RegExp {
  let re = '';
  let i = 0;
  while (i < glob.length) {
    const c = glob[i];
    if (c === '*') {
      if (glob[i + 1] === '*') {
        re += '.*';
        i += 2;
        // skip optional trailing slash
        if (glob[i] === '/') i++;
      } else {
        re += '[^/]*';
        i++;
      }
    } else if (c === '?') {
      re += '[^/]';
      i++;
    } else if (c === '[') {
      const close = glob.indexOf(']', i);
      if (close === -1) {
        re += '\\[';
        i++;
      } else {
        re += glob.slice(i, close + 1);
        i = close + 1;
      }
    } else if (/[.+^$(){}|\\]/.test(c)) {
      re += '\\' + c;
      i++;
    } else {
      re += c;
      i++;
    }
  }
  return new RegExp('^' + re + '$', 'i');
}

export type CompiledFilter = (e: FileEntry, rootPrefix: string) => boolean;

export function compileFilter(filter: FilterDef): CompiledFilter {
  const extSet =
    filter.extensions && filter.extensions.length
      ? new Set(filter.extensions.map((x) => x.toLowerCase().replace(/^\./, '')))
      : null;

  let textTest: ((e: FileEntry, relPath: string) => boolean) | null = null;
  if (filter.textMode === 'regex' && filter.regex) {
    try {
      const re = new RegExp(filter.regex, 'i');
      textTest = (e) => re.test(e.name);
    } catch {
      // invalid regex → match nothing
      textTest = () => false;
    }
  } else if (filter.textMode === 'glob' && filter.glob) {
    try {
      const re = globToRegex(filter.glob);
      textTest = (_e, rel) => re.test(rel);
    } catch {
      textTest = () => false;
    }
  } else if (filter.text) {
    const needle = filter.text.toLowerCase();
    textTest = (e) => e.name.toLowerCase().includes(needle);
  }

  return (e: FileEntry, rootPrefix: string) => {
    if (e.isDir && !filter.includeDirs) return false;
    if (!e.isDir && !filter.includeFiles) return false;
    if (e.hidden && !filter.includeHidden) return false;
    if (e.system && !filter.includeSystem) return false;

    if (extSet && !e.isDir && !extSet.has(e.ext)) return false;

    if (!inRange(e.size, filter.size)) return false;
    if (!inRange(e.mtimeMs, filter.mtime)) return false;
    if (!inRange(e.birthtimeMs, filter.birthtime)) return false;
    if (!inRange(e.depth, filter.depth)) return false;

    if (textTest) {
      // relative path with forward slashes
      const rel =
        e.path.startsWith(rootPrefix)
          ? e.path.slice(rootPrefix.length).replace(/^\/+/, '')
          : e.path;
      if (!textTest(e, rel)) return false;
    }

    return true;
  };
}

export function defaultFilter(): FilterDef {
  return {
    textMode: 'substring',
    includeDirs: true,
    includeFiles: true,
    includeHidden: false,
    includeSystem: false,
  };
}

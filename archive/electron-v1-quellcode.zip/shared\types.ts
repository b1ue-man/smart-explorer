export type FileEntry = {
  /** absolute path with forward slashes for portability */
  path: string;
  /** absolute path of parent dir */
  parent: string;
  /** basename (incl. extension) */
  name: string;
  /** lowercased extension without leading dot, '' for none/dirs */
  ext: string;
  /** byte size — for dirs, the recursive total filled in after scan completes */
  size: number;
  /** file mtime in ms since epoch */
  mtimeMs: number;
  /** birthtime / ctime in ms since epoch */
  birthtimeMs: number;
  /** true if directory */
  isDir: boolean;
  /** true if symlink */
  isSymlink: boolean;
  /** true if hidden (NTFS hidden attribute or leading-dot name) */
  hidden: boolean;
  /** true if system attribute (Windows) */
  system: boolean;
  /** depth from scan root (root = 0) */
  depth: number;
};

export type ScanProgress = {
  scanned: number;
  bytes: number;
  errors: number;
  /** path currently being processed (sampled, not exact) */
  currentPath?: string;
  /** scan duration so far, in ms */
  elapsedMs: number;
  done: boolean;
};

export type ScanOptions = {
  root: string;
  followSymlinks: boolean;
  includeHidden: boolean;
  includeSystem: boolean;
  maxDepth?: number;
};

/** numeric range filter — undefined bounds mean "no bound" */
export type RangeFilter = {
  min?: number;
  max?: number;
};

export type FilterDef = {
  /** plain text search; case-insensitive substring on name */
  text?: string;
  /** regex on name (full match anywhere). Used when textMode === 'regex' */
  regex?: string;
  /** glob pattern on relative path (forward slashes). Used when textMode === 'glob' */
  glob?: string;
  textMode?: 'substring' | 'regex' | 'glob';
  /** lowercased extensions without dot. Empty = any */
  extensions?: string[];
  /** size in bytes */
  size?: RangeFilter;
  /** modified time as epoch ms */
  mtime?: RangeFilter;
  /** birth time as epoch ms */
  birthtime?: RangeFilter;
  /** include directories in results */
  includeDirs: boolean;
  /** include files in results */
  includeFiles: boolean;
  /** include hidden entries */
  includeHidden: boolean;
  /** include system entries (Windows) */
  includeSystem: boolean;
  /** depth range from scan root */
  depth?: RangeFilter;
};

export type SortKey = 'name' | 'path' | 'size' | 'mtime' | 'birthtime' | 'ext' | 'depth';
export type SortDir = 'asc' | 'desc';

export type CopyOptions = {
  /** entries to copy (must share scan root) */
  entries: FileEntry[];
  /** scan root — used to compute relative path for structure preservation */
  root: string;
  /** destination directory */
  dest: string;
  /** preserve folder hierarchy under dest, skipping empty intermediate dirs */
  preserveStructure: boolean;
  /** when destination exists: 'skip' | 'overwrite' | 'rename' */
  conflict: 'skip' | 'overwrite' | 'rename';
  /** move instead of copy */
  move?: boolean;
};

export type CopyProgress = {
  filesDone: number;
  filesTotal: number;
  bytesDone: number;
  bytesTotal: number;
  currentPath?: string;
  elapsedMs: number;
  errors: number;
  done: boolean;
};

export type ScanSummary = {
  totalFiles: number;
  totalDirs: number;
  totalBytes: number;
  byExt: Record<string, { count: number; bytes: number }>;
  oldestMtimeMs?: number;
  newestMtimeMs?: number;
};

export type AppErrorReport = {
  path: string;
  code?: string;
  message: string;
};

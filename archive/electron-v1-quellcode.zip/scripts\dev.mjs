import { spawn } from 'node:child_process';
import { createServer } from 'vite';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { build } from 'esbuild';
import { mkdir, rm } from 'node:fs/promises';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, '..');
const outdir = path.join(root, 'dist-electron');

await rm(outdir, { recursive: true, force: true });
await mkdir(outdir, { recursive: true });

const common = {
  bundle: true,
  platform: 'node',
  format: 'cjs',
  target: 'node20',
  sourcemap: 'inline',
  logLevel: 'info',
  external: ['electron', 'electron-updater', 'trash'],
};

await Promise.all([
  build({ ...common, entryPoints: [path.join(root, 'electron/main.ts')], outfile: path.join(outdir, 'main.cjs') }),
  build({ ...common, entryPoints: [path.join(root, 'electron/preload.ts')], outfile: path.join(outdir, 'preload.cjs') }),
  build({ ...common, entryPoints: [path.join(root, 'electron/workers/scan-worker.ts')], outfile: path.join(outdir, 'scan-worker.cjs') }),
  build({ ...common, entryPoints: [path.join(root, 'electron/workers/copy-worker.ts')], outfile: path.join(outdir, 'copy-worker.cjs') }),
]);

const vite = await createServer({
  configFile: path.join(root, 'vite.config.ts'),
});
await vite.listen();
const url = `http://localhost:${vite.config.server.port}`;
console.log('Vite dev server:', url);

const electron = spawn(
  process.platform === 'win32' ? 'npx.cmd' : 'npx',
  ['electron', '.'],
  {
    cwd: root,
    env: { ...process.env, VITE_DEV_SERVER_URL: url, NODE_ENV: 'development' },
    stdio: 'inherit',
    shell: true,
  }
);

electron.on('close', () => {
  vite.close().finally(() => process.exit(0));
});

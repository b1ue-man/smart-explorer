import type { FileEntry, SortKey, SortDir } from './types';

export function compareEntries(a: FileEntry, b: FileEntry, key: SortKey, dir: SortDir): number {
  // Always group dirs first regardless of sort key (Explorer-style); user can disable later.
  if (a.isDir !== b.isDir) return a.isDir ? -1 : 1;

  const mul = dir === 'asc' ? 1 : -1;
  let cmp = 0;
  switch (key) {
    case 'name':
      cmp = a.name.localeCompare(b.name, undefined, { numeric: true, sensitivity: 'base' });
      break;
    case 'path':
      cmp = a.path.localeCompare(b.path, undefined, { numeric: true, sensitivity: 'base' });
      break;
    case 'size':
      cmp = a.size - b.size;
      break;
    case 'mtime':
      cmp = a.mtimeMs - b.mtimeMs;
      break;
    case 'birthtime':
      cmp = a.birthtimeMs - b.birthtimeMs;
      break;
    case 'ext':
      cmp = a.ext.localeCompare(b.ext);
      if (cmp === 0) cmp = a.name.localeCompare(b.name, undefined, { numeric: true });
      break;
    case 'depth':
      cmp = a.depth - b.depth;
      break;
  }
  return cmp * mul;
}

export function formatBytes(n: number): string {
  if (n < 1024) return `${n} B`;
  const units = ['KB', 'MB', 'GB', 'TB', 'PB'];
  let v = n / 1024;
  let i = 0;
  while (v >= 1024 && i < units.length - 1) {
    v /= 1024;
    i++;
  }
  return `${v >= 100 ? v.toFixed(0) : v >= 10 ? v.toFixed(1) : v.toFixed(2)} ${units[i]}`;
}

export function formatDate(ms: number): string {
  if (!ms) return '';
  const d = new Date(ms);
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  const HH = String(d.getHours()).padStart(2, '0');
  const MM = String(d.getMinutes()).padStart(2, '0');
  return `${yyyy}-${mm}-${dd} ${HH}:${MM}`;
}

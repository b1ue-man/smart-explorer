import { app, BrowserWindow, ipcMain, dialog, shell, Menu, clipboard, nativeImage } from 'electron';
import path from 'node:path';
import { promises as fsp } from 'node:fs';
import { ScanManager } from './scan-manager';
import { CopyManager } from './copy-manager';
import type { CopyOptions, ScanOptions } from '../shared/types';
import { setupAutoUpdate } from './updater';

const isDev = !!process.env.VITE_DEV_SERVER_URL;
let mainWindow: BrowserWindow | null = null;

const scanners = new Map<string, ScanManager>();
const copiers = new Map<string, CopyManager>();

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 900,
    minHeight: 600,
    backgroundColor: '#1a1d23',
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
    },
  });

  Menu.setApplicationMenu(null);

  if (isDev) {
    mainWindow.loadURL(process.env.VITE_DEV_SERVER_URL!);
    mainWindow.webContents.openDevTools({ mode: 'detach' });
  } else {
    mainWindow.loadFile(path.join(__dirname, '..', 'dist', 'index.html'));
  }

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

app.whenReady().then(() => {
  createWindow();
  if (!isDev) {
    setupAutoUpdate(() => mainWindow);
  }
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

// ─── IPC: dialogs ────────────────────────────────────────────────────────────

ipcMain.handle('dialog:pickFolder', async (_e, defaultPath?: string) => {
  if (!mainWindow) return null;
  const r = await dialog.showOpenDialog(mainWindow, {
    properties: ['openDirectory'],
    defaultPath,
  });
  if (r.canceled || !r.filePaths[0]) return null;
  return r.filePaths[0];
});

ipcMain.handle('dialog:saveFolder', async (_e, defaultPath?: string) => {
  if (!mainWindow) return null;
  const r = await dialog.showOpenDialog(mainWindow, {
    properties: ['openDirectory', 'createDirectory'],
    defaultPath,
  });
  if (r.canceled || !r.filePaths[0]) return null;
  return r.filePaths[0];
});

// ─── IPC: scan ───────────────────────────────────────────────────────────────

ipcMain.handle('scan:start', async (e, jobId: string, opts: ScanOptions) => {
  const sm = new ScanManager();
  scanners.set(jobId, sm);
  const wc = e.sender;

  sm.on('entries', (entries) => wc.send(`scan:${jobId}:entries`, entries));
  sm.on('progress', (p) => wc.send(`scan:${jobId}:progress`, p));
  sm.on('error', (msg) => wc.send(`scan:${jobId}:error`, msg));
  sm.on('done', (s) => {
    wc.send(`scan:${jobId}:done`, s);
    scanners.delete(jobId);
  });

  sm.start(opts).catch((err) => wc.send(`scan:${jobId}:error`, err.message));
  return true;
});

ipcMain.handle('scan:cancel', async (_e, jobId: string) => {
  const sm = scanners.get(jobId);
  if (sm) {
    sm.cancel();
    scanners.delete(jobId);
  }
  return true;
});

// ─── IPC: copy / move ────────────────────────────────────────────────────────

ipcMain.handle('copy:start', async (e, jobId: string, opts: CopyOptions) => {
  const cm = new CopyManager();
  copiers.set(jobId, cm);
  const wc = e.sender;
  cm.on('progress', (p) => wc.send(`copy:${jobId}:progress`, p));
  cm.on('done', (errs) => {
    wc.send(`copy:${jobId}:done`, errs);
    copiers.delete(jobId);
  });
  cm.start(opts).catch((err) => wc.send(`copy:${jobId}:done`, [{ path: '', message: err.message }]));
  return true;
});

ipcMain.handle('copy:cancel', async (_e, jobId: string) => {
  const cm = copiers.get(jobId);
  if (cm) {
    cm.cancel();
    copiers.delete(jobId);
  }
  return true;
});

// ─── IPC: misc shell ─────────────────────────────────────────────────────────

ipcMain.handle('shell:openInExplorer', async (_e, p: string) => {
  shell.showItemInFolder(p);
  return true;
});

ipcMain.handle('shell:openPath', async (_e, p: string) => {
  return shell.openPath(p);
});

ipcMain.handle('clipboard:writeText', async (_e, txt: string) => {
  clipboard.writeText(txt);
  return true;
});

ipcMain.handle('clipboard:writePaths', async (_e, paths: string[]) => {
  // Best-effort: write list as text. Native CF_HDROP would need a native module.
  clipboard.writeText(paths.join('\r\n'));
  return true;
});

// ─── IPC: trash / delete ─────────────────────────────────────────────────────

ipcMain.handle('files:trash', async (_e, paths: string[]) => {
  // Use Electron's built-in shell.trashItem (sends to Recycle Bin on Windows)
  let ok = 0;
  let errors: { path: string; message: string }[] = [];
  for (const p of paths) {
    try {
      await shell.trashItem(p);
      ok++;
    } catch (err: any) {
      errors.push({ path: p, message: err.message });
    }
  }
  return { ok, errors };
});

ipcMain.handle('files:permanentDelete', async (_e, paths: string[]) => {
  let ok = 0;
  let errors: { path: string; message: string }[] = [];
  for (const p of paths) {
    try {
      await fsp.rm(p, { recursive: true, force: true });
      ok++;
    } catch (err: any) {
      errors.push({ path: p, message: err.message });
    }
  }
  return { ok, errors };
});

// ─── IPC: drive list ─────────────────────────────────────────────────────────

ipcMain.handle('system:listDrives', async () => {
  if (process.platform !== 'win32') return [];
  const drives: string[] = [];
  for (let c = 65; c <= 90; c++) {
    const letter = String.fromCharCode(c);
    const root = `${letter}:\\`;
    try {
      await fsp.access(root);
      drives.push(root);
    } catch {
      /* not present */
    }
  }
  return drives;
});

ipcMain.handle('system:appVersion', async () => app.getVersion());

ipcMain.handle('system:homeDir', async () => app.getPath('home'));

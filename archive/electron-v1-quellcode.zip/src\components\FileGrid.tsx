import React, { useEffect, useLayoutEffect, useRef, useState } from 'react';
import type { FileEntry, SortDir, SortKey } from '../../shared/types';
import { formatBytes, formatDate } from '../../shared/sort';

const ROW_H = 24;
const HEADER_H = 32;
const OVERSCAN = 12;

type Props = {
  rows: FileEntry[];
  selection: Set<string>;
  sortKey: SortKey;
  sortDir: SortDir;
  onSort: (k: SortKey) => void;
  onSelect: (path: string, mode: 'set' | 'toggle' | 'add' | 'range', anchor?: string) => void;
  onOpen: (e: FileEntry) => void;
  onContextOpen: (path: string) => void;
  rootPrefix: string;
};

export function FileGrid({
  rows,
  selection,
  sortKey,
  sortDir,
  onSort,
  onSelect,
  onOpen,
  onContextOpen,
  rootPrefix,
}: Props) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [scrollTop, setScrollTop] = useState(0);
  const [viewportH, setViewportH] = useState(600);
  const anchorRef = useRef<string | null>(null);

  useLayoutEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    const ro = new ResizeObserver(() => setViewportH(el.clientHeight));
    ro.observe(el);
    setViewportH(el.clientHeight);
    return () => ro.disconnect();
  }, []);

  const totalH = rows.length * ROW_H;
  const startIdx = Math.max(0, Math.floor(scrollTop / ROW_H) - OVERSCAN);
  const endIdx = Math.min(rows.length, Math.ceil((scrollTop + viewportH) / ROW_H) + OVERSCAN);
  const slice = rows.slice(startIdx, endIdx);
  const offsetY = startIdx * ROW_H;

  const onRowClick = (e: React.MouseEvent, entry: FileEntry) => {
    if (e.shiftKey) {
      onSelect(entry.path, 'range', anchorRef.current ?? entry.path);
    } else if (e.ctrlKey || e.metaKey) {
      onSelect(entry.path, 'toggle');
      anchorRef.current = entry.path;
    } else {
      onSelect(entry.path, 'set');
      anchorRef.current = entry.path;
    }
  };

  const headers: { key: SortKey; label: string; w: string; cls?: string }[] = [
    { key: 'name', label: 'Name', w: '2.4fr' },
    { key: 'path', label: 'Pfad', w: '3fr' },
    { key: 'size', label: 'Größe', w: '110px', cls: 'num' },
    { key: 'mtime', label: 'Geändert', w: '160px' },
    { key: 'birthtime', label: 'Erstellt', w: '160px' },
    { key: 'ext', label: 'Typ', w: '70px' },
    { key: 'depth', label: 'Tiefe', w: '60px', cls: 'num' },
  ];

  const cols = headers.map((h) => h.w).join(' ');

  return (
    <div className="grid-wrap">
      <div className="grid-header" style={{ gridTemplateColumns: cols }}>
        {headers.map((h) => (
          <div
            key={h.key}
            className={`gh ${h.cls || ''} ${sortKey === h.key ? 'sorted' : ''}`}
            onClick={() => onSort(h.key)}
            title={`Sortieren nach ${h.label}`}
          >
            {h.label}
            {sortKey === h.key ? (sortDir === 'asc' ? ' ▲' : ' ▼') : ''}
          </div>
        ))}
      </div>

      <div
        className="grid-scroll"
        ref={scrollRef}
        onScroll={(e) => setScrollTop((e.target as HTMLDivElement).scrollTop)}
      >
        <div className="grid-spacer" style={{ height: totalH }}>
          <div className="grid-rows" style={{ transform: `translateY(${offsetY}px)`, gridTemplateColumns: cols }}>
            {slice.map((r, i) => {
              const idx = startIdx + i;
              const sel = selection.has(r.path);
              const rel = r.path.startsWith(rootPrefix)
                ? r.path.slice(rootPrefix.length).replace(/^\/+/, '') || '/'
                : r.path;
              return (
                <div
                  key={r.path}
                  className={`gr ${sel ? 'sel' : ''} ${idx % 2 ? 'odd' : ''}`}
                  style={{ gridTemplateColumns: cols }}
                  onClick={(e) => onRowClick(e, r)}
                  onDoubleClick={() => onOpen(r)}
                  onContextMenu={(e) => {
                    e.preventDefault();
                    if (!sel) onSelect(r.path, 'set');
                    onContextOpen(r.path);
                  }}
                  title={r.path}
                >
                  <div className="gc name">
                    <span className={`icon ${r.isDir ? 'd' : 'f'}`} />
                    {r.name}
                  </div>
                  <div className="gc path">{rel}</div>
                  <div className="gc num">{r.isDir ? '' : formatBytes(r.size)}</div>
                  <div className="gc">{formatDate(r.mtimeMs)}</div>
                  <div className="gc">{formatDate(r.birthtimeMs)}</div>
                  <div className="gc">{r.ext}</div>
                  <div className="gc num">{r.depth}</div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

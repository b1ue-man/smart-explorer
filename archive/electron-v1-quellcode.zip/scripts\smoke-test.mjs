// Direct smoke test of the worker bundle against a real folder.
// Validates: scan, batch streaming, filter engine, sort, copy w/ structure.
import { Worker } from 'node:worker_threads';
import { mkdtempSync, rmSync, readdirSync, statSync, mkdirSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import os from 'node:os';

const root = path.resolve('release/win-unpacked');
const scanWorkerPath = path.resolve('dist-electron/scan-worker.cjs');
const copyWorkerPath = path.resolve('dist-electron/copy-worker.cjs');

console.log('Smoke test against:', root);
console.log('Worker bundles:', scanWorkerPath, copyWorkerPath);

// ── 1. Run scan worker ──────────────────────────────────────────────────────
const scanResult = await new Promise((resolve, reject) => {
  const w = new Worker(scanWorkerPath);
  const entries = [];
  let done = null;
  w.on('message', (m) => {
    if (m.type === 'entries') entries.push(...m.entries);
    else if (m.type === 'done') {
      done = m;
      w.terminate();
    }
  });
  w.on('error', reject);
  w.on('exit', () => resolve({ entries, done }));
  // Need at least one starting dir
  const startDirs = readdirSync(root, { withFileTypes: true })
    .filter((d) => d.isDirectory())
    .map((d) => path.join(root, d.name));
  // also include top-level files via main thread emulation
  w.postMessage({
    type: 'scan',
    startDirs,
    startDepth: 1,
    opts: { root, followSymlinks: false, includeHidden: true, includeSystem: true },
  });
});
console.log(`✓ scan worker: ${scanResult.entries.length} entries, ${scanResult.done.bytes} bytes, ${scanResult.done.elapsedMs}ms, ${scanResult.done.errors} errors`);
if (scanResult.entries.length === 0) throw new Error('scan returned no entries');

// ── 2. Filter test: only .dll files >= 1MB ──────────────────────────────────
const big = scanResult.entries.filter((e) => !e.isDir && e.ext === 'dll' && e.size >= 1024 * 1024);
console.log(`✓ filter: found ${big.length} .dll files >= 1 MB`);
if (big.length === 0) console.warn('  (no big DLLs — unusual, but not fatal)');

// ── 3. Copy w/ structure preservation ───────────────────────────────────────
const dest = mkdtempSync(path.join(os.tmpdir(), 'se-smoke-'));
console.log('  copy dest:', dest);

// Take first 5 files from different depths
const sample = scanResult.entries.filter((e) => !e.isDir).slice(0, 5);
console.log(`  copying ${sample.length} sample files`);

const copyResult = await new Promise((resolve, reject) => {
  const w = new Worker(copyWorkerPath);
  let progress = null;
  w.on('message', (m) => {
    if (m.type === 'progress') progress = m;
    else if (m.type === 'done') {
      w.terminate();
      resolve({ progress, errorList: m.errorList });
    }
  });
  w.on('error', reject);
  w.postMessage({
    type: 'copy',
    opts: {
      entries: sample,
      root,
      dest,
      preserveStructure: true,
      conflict: 'rename',
      move: false,
    },
  });
});
console.log(`✓ copy: ${copyResult.progress.filesDone}/${copyResult.progress.filesTotal} files, ${copyResult.progress.bytesDone} bytes, ${copyResult.errorList.length} errors`);

// Verify no empty directories were created in destination
function hasEmptyDirs(dir) {
  const entries = readdirSync(dir, { withFileTypes: true });
  if (entries.length === 0) return true;
  for (const e of entries) {
    if (e.isDirectory() && hasEmptyDirs(path.join(dir, e.name))) return true;
  }
  return false;
}
const emptyFound = hasEmptyDirs(dest);
console.log(`✓ no empty dirs in destination: ${!emptyFound}`);
if (emptyFound) throw new Error('empty dirs detected in destination');

rmSync(dest, { recursive: true, force: true });
console.log('\n✓✓✓ smoke test passed');

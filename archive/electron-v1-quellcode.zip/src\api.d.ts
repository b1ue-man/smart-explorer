import type { SmartExplorerAPI } from '../electron/preload';

declare global {
  interface Window {
    api: SmartExplorerAPI;
  }
}

export {};

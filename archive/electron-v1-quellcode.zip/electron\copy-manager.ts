import { Worker } from 'node:worker_threads';
import path from 'node:path';
import { EventEmitter } from 'node:events';
import type { CopyOptions, CopyProgress } from '../shared/types';

const WORKER_PATH = path.join(__dirname, 'copy-worker.cjs');

export type CopyEvents = {
  progress: (p: CopyProgress) => void;
  done: (errors: { path: string; message: string }[]) => void;
};

export class CopyManager extends EventEmitter {
  private worker?: Worker;
  private cancelled = false;

  cancel() {
    this.cancelled = true;
    if (this.worker) this.worker.terminate().catch(() => {});
  }

  async start(opts: CopyOptions): Promise<{ path: string; message: string }[]> {
    return new Promise((resolve) => {
      const w = new Worker(WORKER_PATH);
      this.worker = w;
      let errors: { path: string; message: string }[] = [];
      w.on('message', (msg: any) => {
        if (this.cancelled) return;
        if (msg.type === 'progress') this.emit('progress', msg as CopyProgress);
        else if (msg.type === 'done') {
          errors = msg.errorList || [];
          this.emit('done', errors);
          w.terminate().catch(() => {});
          resolve(errors);
        }
      });
      w.on('error', (err) => {
        errors.push({ path: '', message: err.message });
        resolve(errors);
      });
      w.on('exit', () => {
        if (this.cancelled) resolve(errors);
      });
      w.postMessage({ type: 'copy', opts });
    });
  }
}

import { parentPort } from 'node:worker_threads';
import { mkdirSync, statSync, lstatSync, copyFileSync, renameSync, unlinkSync, rmdirSync, existsSync, constants as fsConst } from 'node:fs';
import path from 'node:path';
import type { CopyOptions, FileEntry } from '../../shared/types';

const port = parentPort;
if (!port) throw new Error('copy-worker must be run as a worker thread');

type Msg =
  | { type: 'copy'; opts: CopyOptions };

function ensureDir(dir: string) {
  mkdirSync(dir, { recursive: true });
}

function uniqueDest(target: string): string {
  if (!existsSync(target)) return target;
  const ext = path.extname(target);
  const base = target.slice(0, target.length - ext.length);
  let i = 2;
  while (existsSync(`${base} (${i})${ext}`)) i++;
  return `${base} (${i})${ext}`;
}

/**
 * Copy entries while preserving the relative folder structure under root,
 * but emit no empty intermediate directories. We achieve this by:
 *   1. From the input list, keep only files (and explicitly-selected dirs).
 *   2. For each file, rebuild only the chain of parents needed and copy it.
 *   3. If the user selected an empty dir explicitly, we still skip it
 *      unless `preserveStructure: false` (literal copy), per spec.
 *
 * Spec quote: "ohne dass leere ordner kopiert werden" → never emit empty dirs.
 */
function runCopy(opts: CopyOptions) {
  const t0 = Date.now();
  const root = path.resolve(opts.root).replace(/\\/g, '/');
  const dest = path.resolve(opts.dest).replace(/\\/g, '/');

  // Filter input to files only when preserving structure (dirs are implicit via parents).
  const files = opts.entries.filter((e) => !e.isDir);

  // Total bytes (best-effort — entries already carry stat-time size)
  let bytesTotal = 0;
  for (const f of files) bytesTotal += f.size || 0;

  let filesDone = 0;
  let bytesDone = 0;
  let errors = 0;
  const filesTotal = files.length;
  const errorList: { path: string; message: string }[] = [];
  let lastProgressAt = 0;

  function emitProgress(currentPath?: string, force = false) {
    const now = Date.now();
    if (!force && now - lastProgressAt < 100) return;
    lastProgressAt = now;
    port!.postMessage({
      type: 'progress',
      filesDone,
      filesTotal,
      bytesDone,
      bytesTotal,
      currentPath,
      elapsedMs: now - t0,
      errors,
      done: false,
    });
  }

  function relFromRoot(p: string): string {
    const np = p.replace(/\\/g, '/');
    if (!np.startsWith(root)) return path.basename(np);
    let rel = np.slice(root.length).replace(/^\/+/, '');
    return rel || path.basename(np);
  }

  for (const f of files) {
    const src = f.path.replace(/\\/g, '/');
    const rel = opts.preserveStructure ? relFromRoot(src) : path.basename(src);
    let target = path.join(dest, rel).replace(/\\/g, '/');

    try {
      ensureDir(path.dirname(target));

      if (existsSync(target)) {
        if (opts.conflict === 'skip') {
          filesDone++;
          continue;
        } else if (opts.conflict === 'rename') {
          target = uniqueDest(target);
        } else {
          // overwrite: remove existing target file (only if it is a file)
          try {
            const ts = lstatSync(target);
            if (ts.isFile()) unlinkSync(target);
          } catch {
            /* ignore */
          }
        }
      }

      if (opts.move) {
        try {
          renameSync(src, target);
        } catch (e: any) {
          // cross-volume rename → fallback to copy + unlink
          if (e && e.code === 'EXDEV') {
            copyFileSync(src, target, fsConst.COPYFILE_FICLONE);
            unlinkSync(src);
          } else {
            throw e;
          }
        }
      } else {
        copyFileSync(src, target, fsConst.COPYFILE_FICLONE);
      }

      filesDone++;
      bytesDone += f.size || 0;
      emitProgress(src);
    } catch (e: any) {
      errors++;
      errorList.push({ path: src, message: e?.message ?? String(e) });
      filesDone++;
      emitProgress(src);
    }
  }

  // After move, prune now-empty source dirs (best effort)
  if (opts.move && opts.preserveStructure) {
    const dirSet = new Set<string>();
    for (const f of files) {
      let p = path.dirname(f.path.replace(/\\/g, '/'));
      while (p.length > root.length) {
        dirSet.add(p);
        const next = path.dirname(p);
        if (next === p) break;
        p = next;
      }
    }
    const dirs = Array.from(dirSet).sort((a, b) => b.length - a.length);
    for (const d of dirs) {
      try { rmdirSync(d); } catch { /* not empty or already gone */ }
    }
  }

  port!.postMessage({
    type: 'progress',
    filesDone,
    filesTotal,
    bytesDone,
    bytesTotal,
    elapsedMs: Date.now() - t0,
    errors,
    done: true,
  });
  port!.postMessage({ type: 'done', errorList });
}

port.on('message', (msg: Msg) => {
  if (msg.type === 'copy') runCopy(msg.opts);
});
